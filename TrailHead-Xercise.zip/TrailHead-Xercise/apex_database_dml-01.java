/*Create a method for inserting accounts.*/
/*To pass this challenge, create an Apex class that inserts a new account named after an incoming parameter. If the account is successfully inserted, the method should return the account record. If a DML exception occurs, the method should return null.*/

//The Apex class must have a public static method called insertNewAccount
public class AccountHandler {
    //The method must accept an incoming string as a parameter, which will be used to create the Account name
    public static Account insertNewAccount(String accountNameStr){
      	//The method must insert the account into the system and then return the record
      	//The method must also accept an empty string, catch the failed DML and then return null
  		Account accountName = new Account(Name=accountNameStr);
        System.debug('test miklos'+accountNameStr);
        try {
            insert accountName;
            return accountName;
            
        } catch (DmlException e) {
            return null;
        }      
            
    }
}